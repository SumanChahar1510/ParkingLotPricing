import { CommentsRequest } from './comments-request';

describe('CommentsRequest', () => {
  it('should create an instance', () => {
    expect(new CommentsRequest()).toBeTruthy();
  });
});
