export class CommentsRequest {
    constructor(
        public countryName: String ,
        public comment: String 
        ){}
}
