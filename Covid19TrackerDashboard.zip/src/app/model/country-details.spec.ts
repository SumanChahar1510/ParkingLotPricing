// import { CountryDetails } from './country-details';

// describe('CountryDetails', () => {
//   it('should create an instance', () => {
//     expect(new CountryDetails()).toBeTruthy();
//   });
// });
