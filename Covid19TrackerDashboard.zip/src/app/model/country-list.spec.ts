// import { CountryList } from './country-list';

// describe('CountryList', () => {
//   it('should create an instance', () => {
//     expect(new CountryList()).toBeTruthy();
//   });
// });
