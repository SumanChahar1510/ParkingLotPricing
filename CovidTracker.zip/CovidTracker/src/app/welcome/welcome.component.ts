import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  headers = ["Confirmed Cases", "Critical Cases", "Deaths", "Recovered"];

  rows = [
    {
      "ConfirmedCases" : "1000",
      "CriticalCases" : "200",
      "Deaths" : "21",
      "Recovered" : "233"
    },
    {
      "ConfirmedCases" : "2000",
      "CriticalCases" : "300",
      "Deaths" : "21",
      "Recovered" : "233"
    }];

  constructor() { }

  ngOnInit(): void {
  }

}
