package com.codetest.java.api.Controller;

import com.codetest.java.api.DTOs.ParkingLotRequestDTO;
import com.codetest.java.api.Services.ParkingLotPricingImpl;
import com.codetest.java.api.Services.ParkingLotPricingService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1.0/parking_lot_price")
@RequiredArgsConstructor
public class ParkingLotController {
    private final ParkingLotPricingImpl parkingLotPricingService;

    @PostMapping(value = "/get_price", produces = MediaType.APPLICATION_JSON_VALUE)
    public Long getPrice(@RequestBody ParkingLotRequestDTO parkingLotRequestDTO) {
        parkingLotPricingService.getBill(parkingLotRequestDTO);
        return parkingLotPricingService.getBill(parkingLotRequestDTO);
    }
}
