package com.codetest.java.api.DTOs;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
public class ParkingLotRequestDTO {
    private String vehicleID;
    private LocalDateTime entryTime;
    private LocalDateTime exitTime;

}
