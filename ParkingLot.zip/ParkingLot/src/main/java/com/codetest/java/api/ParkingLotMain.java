package com.codetest.java.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParkingLotMain {
    public static void main(String[] args) {
        SpringApplication.run(ParkingLotMain.class, args);
    }
}
