package com.codetest.java.api.Services;

import com.codetest.java.api.DTOs.ParkingLotRequestDTO;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class ParkingLotPricingImpl implements ParkingLotPricingService {
    @Override
    public Long getBill(ParkingLotRequestDTO parkingLotRequestDTO) {
        int parkingTime = parkingLotRequestDTO.getEntryTime().getMinute() - parkingLotRequestDTO.getExitTime().getMinute();
        if (parkingLotRequestDTO.getEntryTime().getDayOfWeek().toString() == "SATURDAY" || parkingLotRequestDTO.getEntryTime().getDayOfWeek().toString() == "SUNDAY") {
            if (parkingTime < 2) {
                return 5l;
            } else if (parkingTime > 2 && parkingTime <= 5) {
                return 8l;
            } else if (parkingTime > 5 && parkingTime <= 10) {
                return 12l;
            } else if (parkingTime > 10 && parkingTime <= 15) {
                return 18l;
            } else return 25l;
        } else {
            if (parkingTime < 2) {
                return 7l;
            } else if (parkingTime > 2 && parkingTime <= 5) {
                return 10l;
            } else if (parkingTime > 5 && parkingTime <= 10) {
                return 15l;
            } else if (parkingTime > 10 && parkingTime <= 15) {
                return 22l;
            } else return 30l;

        }
    }
}
