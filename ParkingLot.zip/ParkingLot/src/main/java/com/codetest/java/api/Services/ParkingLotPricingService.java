package com.codetest.java.api.Services;

import com.codetest.java.api.DTOs.ParkingLotRequestDTO;

public interface ParkingLotPricingService {

    public Long getBill( ParkingLotRequestDTO parkingLotRequestDTO);
}
